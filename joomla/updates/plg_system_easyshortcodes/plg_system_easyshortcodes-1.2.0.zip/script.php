<?php
/**
 * @package    plg_system_easyshortcodes
 * @subpackage Installer Script
 * @author     htmgarcia
 * @license    GNU General Public License version 2 or later
 */

defined('_JEXEC') || die;

use Joomla\CMS\Factory;

/**
 * Script file for the Easy Shortcodes plugin
 */
class PlgSystemEasyshortcodesInstallerScript
{
    /**
     * Method to run after installation.
     *
     * @param   string  $type    The type of change (install, update, discover_install).
     * @param   object  $parent  The parent class calling this method.
     *
     * @return  void
     */
    public function postflight($type, $parent)
    {
        if ($type === 'install') {
            // Enable the plugin
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('easyshortcodes'));
            $db->setQuery($query);
            $db->execute();
        }
    }
}