CREATE TABLE IF NOT EXISTS `#__jvisualcss_items` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`title` VARCHAR(255)  NOT NULL ,
`state` TINYINT(4) NOT NULL DEFAULT 1,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`css` MEDIUMTEXT NULL ,
`default` TINYINT(1) NOT NULL DEFAULT 0,
PRIMARY KEY (`id`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

INSERT INTO `#__jvisualcss_items` (`title`, `created_by`, `modified_by`, `css`, `default`, `state`) 
VALUES ('Default Style', 0, 0, NULL, 1, 1);
