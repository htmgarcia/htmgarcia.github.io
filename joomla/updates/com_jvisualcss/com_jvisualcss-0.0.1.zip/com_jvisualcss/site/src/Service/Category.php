<?php

/**
 * @version    CVS: 0.0.1
 * @package    Com_Jvisualcss
 * @author     htmgarcia <htmgarcia@gmail.com>
 * @copyright  2025 htmgarcia
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jvisualcss\Component\Jvisualcss\Site\Service;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Categories\Categories;
/**
 * Content Component Category Tree
 *
 * @since  0.0.1
 */

