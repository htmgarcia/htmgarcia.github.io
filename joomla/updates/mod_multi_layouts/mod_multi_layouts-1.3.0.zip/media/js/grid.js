document.addEventListener('DOMContentLoaded', function () {
    // Get all container elements
    var containers = document.querySelectorAll('.multilayouts-grid--items');
    
    containers.forEach(function(container) {
        var gridType = container.getAttribute('data-grid') || 'masonry-columns';
        let options = {};

        switch (gridType) {
            default:
            case 'masonry-columns':
                options = {
                    itemSelector: '.multilayouts-grid--item'
                };
                break;
        }

        // Initialize Isotope for this container
        var iso = new Isotope(container, options);

        // Find the corresponding filters for this container
        var parentGrid = container.closest('.multilayouts-grid');
        var filters = parentGrid ? parentGrid.querySelector('[data-filters]') : null;
        
        if (filters) {
            var buttons = filters.querySelectorAll('button');

            buttons.forEach(function (button) {
              button.addEventListener('click', function () {
                // Remove .is-checked from all buttons in this filter group
                buttons.forEach(function (btn) {
                  btn.classList.remove('is-checked');
                });

                // Add .is-checked to the clicked button
                this.classList.add('is-checked');

                // Get the filter value from data-filter attribute
                var filterValue = this.getAttribute('data-filter');

                // Apply the filter to this specific isotope instance
                iso.arrange({ filter: filterValue });

                // Prevent default button behavior
                return false;
              });
            });
        }
    });
});
