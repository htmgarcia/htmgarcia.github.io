<?php
/**
 * Content Plugin for Joomla! - Inner Content
 *
 * @author     Valentin Garcia <htmgarcia@gmail.com>
 * @copyright  Copyright 2025 htmgarcia.com
 * @license    GNU Public License version 3 or later
 * @link       https://htmgarcia.com/joomla-extensions/inner-content
 */

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

/**
 * Class PlgContentInnercontent
 *
 * @since  0.0.1
 */
class PlgContentInnercontent extends CMSPlugin
{
    /**
     * Event method onContentBeforeDisplay
     *
     * @param   string  $context  The context of the content being passed to the plugin
     * @param   mixed   &$row     An object with a "text" property
     * @param   mixed   &$params  Additional parameters
     * @param   int     $page     Optional page number
     *
     * @return  null
     *
     * @since 0.0.1
     */
    public function onContentBeforeDisplay($context, &$row, &$params, $page = 0)
    {

        if ($context == 'com_content.article') {

            $block_1            = $this->params->get('block_1', '') . $this->params->get('block_1_editor', '');
            $block_1_location   = $this->params->get('block_1_location', 2);
            $block_2            = $this->params->get('block_2', '') . $this->params->get('block_2_editor', '');
            $block_2_location   = $this->params->get('block_2_location', 5);
            $block_3            = $this->params->get('block_3', '') . $this->params->get('block_3_editor', '');
            $block_3_location   = $this->params->get('block_3_location', 9);

            // Output article's content
            $row->text  = $this->injectBlocks(
                $row->text,
                array(
                    $block_1,
                    $block_2,
                    $block_3
                ),
                array(
                    $block_1_location,
                    $block_2_location,
                    $block_3_location
                )
            );

            // Render modules and other plugins support
			$row->text = Joomla\CMS\HTML\HTMLHelper::_( 'content.prepare', $row->text );
        }
    }


    /**
     * Set custom block between paragraphs
     *
     * @param   mixed   $blocks     The custom HTML of each set
     * @param   mixed   $location   Display $blocks after these paragraphs
     * @param   string  $content    The full HTML from the article
     *
     * @return  string
     *
     * @since 0.0.1
     */
    protected function injectBlocks($content, $blocks = array(), $location = array()) {

	    $close      = '</p>';
	    $paragraphs = explode($close, $content);
        $i          = 0;

	    foreach ($paragraphs as $index => $paragraph) {
            if (trim($paragraph)) {
	            $paragraphs[$index] .= $close;
	        }
	        if (in_array($index + 1, $location)) {
	            $paragraphs[$index] .= $blocks[$i];
                $i++;
	        }
	    }
	    return implode( '', $paragraphs );
    }
}
