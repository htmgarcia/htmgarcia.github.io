// Add to your existing JVisualCSS namespace
if (typeof JVisualCSS === 'undefined') {
    var JVisualCSS = {};
}

// Navigation handling
JVisualCSS.currentPath = '';
JVisualCSS.pendingPath = '';

// Add to the top of the file with other JVisualCSS properties
JVisualCSS.toggleIframeOverlay = function(show) {
    let overlay = document.getElementById('preview-site-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'preview-site-overlay';
        overlay.style.cssText = `
            position: absolute;
            top: 41px; /* Height of the URL input + margin */
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.1);
            z-index: 999; /* Lower than the alert's z-index */
            cursor: not-allowed;
            pointer-events: ${show ? 'all' : 'none'};
        `;
        
        // Get the iframe's container
        const iframeContainer = document.getElementById('preview-site-edit');
        if (iframeContainer) {
            if (window.getComputedStyle(iframeContainer).position === 'static') {
                iframeContainer.style.position = 'relative';
            }
            // Insert overlay before the iframe but after the URL input
            const iframe = document.getElementById('preview-site-edit-iframe');
            iframeContainer.insertBefore(overlay, iframe);
        }
    }
    overlay.style.display = show ? 'block' : 'none';
    overlay.style.pointerEvents = show ? 'all' : 'none';
};

// Add this helper function to check if navigation alert is visible
JVisualCSS.isNavigationAlertVisible = function() {
    const saveAlert = document.getElementById('save-alert');
    return !saveAlert.classList.contains('d-none');
};

document.addEventListener('DOMContentLoaded', function() {
    window.pickrInstances = {};
    const iframe = document.getElementById('preview-site-edit-iframe');
    const controls = document.getElementById('jvisual-css-editor');
    const saved_css = document.getElementById('jform_css');

    let all_css = [];
    // || [];

    // Is empty?
    if (saved_css.value.trim()) {
        try {
            all_css = JSON.parse(saved_css.value);
        } catch (e) {
            console.log('There was a problem declaring all_css...')
        }
    }   

    /**
     * Support HTML tags
     */
    const tags = {
        a: ['background-color', 'border-color', 'border-style', 'border-width', 'color', 'font-size', 'font-weight', 'margin', 'padding', 'text-decoration'],
        button: ['background-color', 'border-color', 'border-style', 'border-width', 'color', 'font-size', 'font-weight', 'margin', 'padding'],
        div: ['background-color', 'border-color', 'border-style', 'border-width', 'color', 'font-size', 'font-weight', 'margin', 'padding'],
        h1: ['color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        h2: ['color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        h3: ['color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        h4: ['color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        h5: ['color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        h6: ['color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        header: ['background-color', 'border-color', 'border-style', 'border-width', 'color', 'font-size', 'font-weight', 'margin', 'padding'],
        input: ['border-color', 'border-style', 'border-width', 'color', 'margin', 'padding'],
        legend: ['color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        li: ['color', 'font-size', 'font-weight', 'line-height'],
        ol: ['color', 'font-size', 'font-weight', 'margin', 'padding'],
        p: ['border-color', 'border-style', 'border-width', 'color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        section: ['background-color', 'color', 'font-size', 'font-weight', 'line-height', 'margin', 'padding'],
        ul: ['color', 'font-size', 'font-weight', 'margin', 'padding']
    };

    /**
     * Options for border-style properties
     */
    const border_styles = [
        {
            value: 'none',
            label: 'None',
        },
        {
            value: 'solid',
            label: 'Solid',
        },
        {
            value: 'dotted',
            label: 'Dotted',
        },
        {
            value: 'dashed',
            label: 'Dashed',
        }
    ];

    /**
     * CSS properties config
     */
    const properties = {
        'background-color': {
            type: 'color',
            label: 'Background',
        },
        'border-color': {
            type: 'multiple',
            label: 'Border color',
            properties: [
                'border-top-color',
                'border-right-color',
                'border-bottom-color',
                'border-left-color'
            ]
        },
        'border-top-color': {
            type: 'color',
            label: 'Border top color',
        },
        'border-right-color': {
            type: 'color',
            label: 'Border right color',
        },
        'border-bottom-color': {
            type: 'color',
            label: 'Border bottom color',
        },
        'border-left-color': {
            type: 'color',
            label: 'Border left color',
        },
        'border-style': {
            type: 'multiple',
            label: 'Border style',
            properties: [
                'border-top-style',
                'border-right-style',
                'border-bottom-style',
                'border-left-style'
            ]
        },
        'border-top-style': {
            type: 'select',
            label: 'Border top style',
            options: border_styles
        },
        'border-right-style': {
            type: 'select',
            label: 'Border right style',
            options: border_styles
        },
        'border-bottom-style': {
            type: 'select',
            label: 'Border bottom style',
            options: border_styles
        },
        'border-left-style': {
            type: 'select',
            label: 'Border left style',
            options: border_styles
        },
        'border-width': {
            type: 'multiple',
            label: 'Border width',
            properties: [
                'border-top-width',
                'border-right-width',
                'border-bottom-width',
                'border-left-width'
            ]
        },
        'border-top-width': {
            type: 'number',
            label: 'Border top width',
            metric: [
                'px'
            ]
        },
        'border-right-width': {
            type: 'number',
            label: 'Border right width',
            metric: [
                'px'
            ]
        },
        'border-bottom-width': {
            type: 'number',
            label: 'Border bottom width',
            metric: [
                'px'
            ]
        },
        'border-left-width': {
            type: 'number',
            label: 'Border left width',
            metric: [
                'px'
            ]
        },
        color: {
            type: 'color',
            label: 'Color'
        },
        'font-size': {
            type: 'number',
            label: 'Font size',
            metric: [
                'px',
                //'em',
                //'rem'
            ]
        },
        'font-weight': {
            type: 'select',
            label: 'Font weight',
            options: [
                {
                    value: 'normal',
                    label: 'normal',
                },
                {
                    value: 'bold',
                    label: 'bold',
                },
                {
                    value: 'bolder',
                    label: 'bolder',
                },
                {
                    value: 'lighter',
                    label: 'lighter',
                },
                {
                    value: 100,
                    label: '100',
                },
                {
                    value: 200,
                    label: '200',
                },
                {
                    value: 300,
                    label: '300',
                },
                {
                    value: 400,
                    label: '400',
                },
                {
                    value: 500,
                    label: '500',
                },
                {
                    value: 600,
                    label: '600',
                },
                {
                    value: 700,
                    label: '700',
                },
                {
                    value: 800,
                    label: '800',
                },
                {
                    value: 900,
                    label: '900',
                }
            ]
        },
        'line-height': {
            type: 'number',
            label: 'Line height',
            metric: [
                'px',
                //'em',
                //'rem'
            ]
        },
        'margin': {
            type: 'multiple',
            label: 'Margin',
            properties: [
                'margin-top',
                'margin-right',
                'margin-bottom',
                'margin-left'
            ]
        },
        'margin-top': {
            type: 'number',
            label: 'Margin top',
            metric: [
                'px',
                'auto'
            ]
        },
        'margin-right': {
            type: 'number',
            label: 'Margin right',
            metric: [
                'px',
                'auto'
            ]
        },
        'margin-bottom': {
            type: 'number',
            label: 'Margin bottom',
            metric: [
                'px',
                'auto'
            ]
        },
        'margin-left': {
            type: 'number',
            label: 'Margin left',
            metric: [
                'px',
                'auto'
            ]
        },
        'padding': {
            type: 'multiple',
            label: 'Padding',
            properties: [
                'padding-top',
                'padding-right',
                'padding-bottom',
                'padding-left'
            ]
        },
        'padding-top': {
            type: 'number',
            label: 'Padding top',
            metric: [
                'px'
            ]
        },
        'padding-right': {
            type: 'number',
            label: 'Padding right',
            metric: [
                'px'
            ]
        },
        'padding-bottom': {
            type: 'number',
            label: 'Padding bottom',
            metric: [
                'px'
            ]
        },
        'padding-left': {
            type: 'number',
            label: 'Padding left',
            metric: [
                'px'
            ]
        },
        'text-decoration': {
            type: 'select',
            label: 'Text decoration',
            options: [
                {
                    value: 'none',
                    label: 'None',
                },
                {
                    value: 'underline',
                    label: 'Underline',
                },
                {
                    value: 'overline',
                    label: 'Overline',
                },
                /*{
                    value: 'blink',
                    label: 'Blink',
                },*/
                {
                    value: 'line-through',
                    label: 'Line through',
                }
            ]
        },
    };

    /**
     * Special values that are not numbers
     */
    const specialValues = [
        'auto'
    ];

    /**
     * Process CSS values
     * 
     * @since 0.0.5 - Added selector param
     * 
     * @param {string} property CSS property. e.g. 'color', 'background-color', etc.
     * @param {string} value    CSS property value. e.g. '10px', '#ff0000', etc.
     * @param {string} selector CSS selector
     * 
     * @return html
     */
    const processCssProp = function (property, value, selector = false) {
        const data = properties[property];

        const newValue = splitValue(property, value, selector);

        //console.log('newValue', value, newValue);

        // newValue is false? Stop process here!
        if (!newValue) {
            console.log(`newValue is false for ${property}`);
            return false;
        }

        // newValue is an array? Means the value includes a metric. e.g. '16px' -> ['16','px']
        if (Array.isArray(newValue) && newValue.length === 5) {
            // newValue uses a metric (e.g. 'px') in the last position
            return elementLayout(property, data.label, newValue, newValue[4]);
        } else if (Array.isArray(newValue) && newValue.length === 2) {
            // newValue use metric in the second position
            return elementLayout(property, data.label, newValue, newValue[1]);
        } else if (Array.isArray(newValue) && newValue.length === 1) {
            // newValue doesn't use metric
            return elementLayout(property, data.label, newValue);
        }
    }

    /**
     * Generate the <input type="number">
     * 
     * @since 0.0.5
     * 
     * @param {string} property 
     * @param {integer} value 
     * @param {string} isDisabled
     * 
     * @returns html
     */
    const elementLayoutNumber = function (property, value, isDisabled) {
        return `<input type="number" data-type="number" data-property="${property}" class="form-control form-control-sm jvisual-css-field-edit" name="jvisualcss_property[${property}][base]" value="${value}"${isDisabled}>`;
    }

    /**
     * Generate the <input type="number">
     * 
     * @since 0.0.5
     * 
     * @param {string} property 
     * @param {string} label
     * 
     * @returns html
     */
    const elementLayoutHeader = function (property, label) {
        return `<div class="row g-3 mb-3 header--${property}"><h4>${label}</h4></div>`;
    }

    /**
     * Render HTML layout for a single CSS element
     * 
     * @param {string} property     CSS property. e.g. 'color', 'background-color', etc.
     * @param {string} label        e.g. 'Background color'
     * @param {string|array} value  CSS property value without metric. e.g. '10', '#ff0000', etc.
     * @param {string} metric       e.g. 'px'
     * 
     * @returns html
     */
    const elementLayout = function (property, label, value, metric = false) { 
        const data = properties[property];
        const resetBtn = `<button class="jvisual-css--remove-property btn btn-danger btn-sm jvisual-css--btn-sm" data-property="${property}">Reset</button>`;
        
        let html = ``;
        html += `<div class="row g-3 mb-3">
            <label class="jvisual-css--label-property col-sm-5 col-form-label col-form-label-sm">${label}${resetBtn}</label>
            <div class="col-sm">`;
                
                switch (data.type) {
                    case 'number':
                        // For margin-[side] property values
                        const isDisabled = metric && metric === 'auto' ? ' disabled' : '';
                        html += elementLayoutNumber(property, value[0], isDisabled);
                    break;
                    case 'color':
                        //console.log('Creating color input for:', property, value);
                        html += `<div class="color-picker-wrapper d-flex align-items-center gap-2">
                            <button type="button" class="color-picker-button" style="width: 32px; height: 32px; padding: 0; border: 1px solid #ccc; border-radius: 4px; background-color: ${value};"></button>
                            <input type="text" class="form-control form-control-sm color-picker-input jvisual-css-field-edit" 
                                data-type="color" data-property="${property}" 
                                name="jvisualcss_property[${property}][base]" value="${value[0]}">
                        </div>`;
                    break;
                    case 'select':
                        html += `<select class="form-select form-select-sm jvisual-css-field-edit" data-type="select" data-property="${property}" name="jvisualcss_property[${property}][base]">`;

                        html += data.options.map(option => {
                            const selected = String(value[0]) === String(option.value) ? ' selected' : '';
                            return `<option value="${option.value}"${selected}>${option.label}</option>`;
                        }).join('\n');

                        html += `</select>`;
                    break;
                    // 4 means: 4 values. e.g. for margin: 10px 0 19px 11px
                    case 'multiple4':
                        console.log('multiple4', property, value);
                        const positions = ['t', 'r', 'b', 'l'];
                        const labels = ['Top', 'Right', 'Bottom', 'Left'];

                        for (let i = 0; i < 4; i++) {   
                            html += `<label>${labels[i]}</label> <input type="text" data-type="multiple4[${positions[i]}]" data-property="${property}" class="form-control form-control-sm w-60" name="jvisualcss_property[${property}][${positions[i]}]" value="${value[i]}">`;
                        }
                    break;
                }
            
            html += `</div>`;

            if (data.metric && data.metric.length) {
                const isDisabled = data.metric.length === 1 ? ' disabled' : '';

                html += `<div class="col-sm ps-0">`;
                    html += `<select class="form-select form-select-sm" data-type="select" data-property="${property}" data-parent="jvisualcss_property__${property}" name="jvisualcss_property[${property}][metric]"${isDisabled}>`;

                        html += data.metric.map(unit => {
                            // @TODO CONTINUE HERE!!!!!
                            //const storedMetric = all_css.find(item => item.selector === cssSelector(element))?.properties[property]?.metric || metric;
                            //console.log('storedMetric', property, storedMetric);
                            
                            const selected = unit === metric ? ' selected' : '';
                            return `<option value="${unit}"${selected}>${unit}</option>`;
                        }).join('\n');

                    html += `</select>`;
                html += `</div>`;
            }

        html += `</div>`;
        html += `</div>`;

        return html;
    }

    /**
     * Take the CSS value and split into number + metric if is the case
     * 
     * @since 0.0.5 - Added selector param
     * 
     * @param {string} property CSS property. e.g. 'color', 'background-color', etc.
     * @param {mixed} value     CSS property value. e.g. '10px', '#ff0000', etc.
     * @param {string} selector CSS selector
     * 
     * @returns array e.g. ['16','px'], ['#ff0000']
     */
    const splitValue = function (property, value, selector = false) {
        const data = properties[property];
        let value_override = null;

        // @since 0.0.5 - Due computed style doesn't support values different to px
        if (['margin-top', 'margin-right', 'margin-bottom', 'margin-left'].includes(property) && selector) {
            // Look for the selector item previously stored 
            // and override its return value if stored as 'auto'
            const existing = all_css.find(item => item.selector === selector);
            if (typeof existing !== 'undefined' 
                && typeof existing.properties[[property]] !== 'undefined'
                && existing.properties[[property]].metric === 'auto'
            ) {
                value_override = existing.properties[[property]].metric;
            }
        }

        // No data? Get out of here!
        if (!data) {
            console.log(`Property ${property} not found`);
            return false;
        }

        // Handle multiple4 case
        if (data.type === 'multiple4') {
            const values = value.split(' '); // Split the input value by spaces
            const result = [];
            let unit = ''; // Variable to hold the first unit found

            // Process each value (match numbers and optional units or 'auto')
            values.forEach((val) => {
                const match = val.match(/(\d*\.?\d+)([a-zA-Z%]*)/); // Match number and optional unit
                if (match) {
                    result.push(parseFloat(match[1])); // Push the numeric part
                    // Check if a unit is found and assign it to the unit variable if not already set
                    if (!unit && match[2]) {
                        unit = match[2]; // Assign the first unit found
                    }
                } else {
                    result.push(val); // Push the keyword (like 'auto')
                }
            });
        
            // Ensure we have exactly 4 values
            while (result.length < 4) {
                result.push(0); // Fill with 0 if less than 4
            }
        
            // If we have more than 4 values, truncate to the first 4
            if (result.length > 4) {
                result.length = 4;
            }
        
            // Adjust the result to match CSS shorthand rule for margin
            if (result.length === 1) {
                result.push(result[0], result[0]); // [top, right, bottom, left] (1 value)
            } else if (result.length === 2) {
                result.push(result[0], result[1]); // [top, right, bottom, left] (2 values)
            } else if (result.length === 3) {
                result.push(result[1]); // [top, right, bottom, left] (3 values)
            }
        
            // Prepare the final array (top, right, bottom, left, unit)
            const finalValues = [
                result[0],  // Top
                result[1],  // Right
                result[2],  // Bottom
                result[3],  // Left
                unit || 'px' // Use the extracted unit or default to 'px'
            ];
        
            // Handle special case where 'auto' is present
            if (result[1] === 'auto') {
                finalValues[1] = 'auto'; // Ensure right is 'auto'
                finalValues[3] = 'auto'; // Ensure left is 'auto'
            }
        
            return finalValues;
        }
        
        // @since 0.0.5 - Is an overriden value? Return adjusted value
        if (value_override) {
            // @TODO - Fix this! Is not working as expected. 
            // Extract stored (even if is disabled) px value
            const value_px = splitValue(property, value);
            //console.log('value px', [value_px[0], value_override]);
            return [value_px[0], value_override]; // e.g. ['10', 'auto']
        }

        // This property doesn't have metric? Return value as is
        if (!data.metric || !data.metric.length) {
            return [value];
        }

        // Merge all the supported metrics and regex it. e.g. 'px|em|rem'
        const validMetrics = data.metric ? data.metric.join('|') : '';
        const metricRegex = new RegExp(`(\\d*\\.?\\d+)(${validMetrics})?$`);  // Changed regex to support decimals

        // Does the metric from value exists in data.metric?
        const match = value.match(metricRegex);

        // Metric (e.g. 'px') from value is not available in data.metric? Get out of here!
        if (!match || !match[0] || !match[1] || !match[2]) {
            console.log(`match not found for ${property} : ${value}`, match, match[0], match[1], match[2]);
            return false;
        }

        return [
            match[1],
            match[2]
        ];
    }

    /**
     * Build the HTML form field for CSS selector
     * 
     * @param {HTMLElement} element 
     * 
     * @returns string
     */
    const processCssSelector = function (element) {
        /*const options = {
            strict: cssSelector(element),
            regular: cssSelector(element, 'regular'),
            tags: cssSelector(element, 'tags'),
            simple: cssSelector(element, 'simple')
        };

        let html = '';

        html += `<select id="jvisualcss-data-selector" class="form-select form-select-sm w-100" disabled>`;

            for (const key in options) {
                if (options.hasOwnProperty(key)) {
                    html += `<option value="${options[key]}">${options[key]}</option>`;
                }
            }

        html += `</select>`;

        return html;*/

        //return `${cssSelector(element)}<br><br>${cssSelector(element, 'regular')}<br><br>${cssSelector(element, 'tags')}<br><br>${cssSelector(element, 'simple')}<br><br><input type="hidden" value="${cssSelector(element)}" id="jvisualcss-data-selector" />`;
        return `<input type="hidden" value="${cssSelector(element)}" id="jvisualcss-data-selector" />`;
    }

    /**
     * Build CSS selector
     * 
     * @param {HTMLElement} element 
     * @param {string} type             'strict'  - Uses '>' symbol for maximum specificity
     *                                   'regular' - Like 'strict' but without '>' symbol
     *                                   'tags'    - Uses only tag names (no classes or IDs)
     *                                   'simple'  - Only returns the body + element's tag name
     * 
     * @returns {string}
     */
    const cssSelector = function (element, type = 'strict') {
        let path = [];
        let currentElement = element;

        while (currentElement && currentElement.tagName !== 'BODY') {
            let selector = currentElement.tagName.toLowerCase(); // Always get the tag name

            if (type !== 'tags' && type !== 'simple') { // Skip IDs and classes if 'tags' or 'simple'
                if (currentElement.id) {
                    selector += `#${currentElement.id}`;
                } else if (currentElement.classList.length > 0) {
                    selector += `.${Array.from(currentElement.classList).join('.')}`;
                }
            }

            path.unshift(selector);
            currentElement = currentElement.parentElement;
        }

        path.unshift('body'); // Always include 'body'

        if (type === 'strict') {
            return path.join(' > ');
        } else if (type === 'regular') {
            return path.join(' ');
        } else if (type === 'tags') {
            return path.map(tag => tag.split(/[#.]/)[0]).join(' > '); // Remove IDs & classes
        } else if (type === 'simple') {
            return 'body ' + element.tagName.toLowerCase(); // Only return the boidy and tag name
        }
    };

    /**
     * Create a box to highlight current hovered element
     * 
     * @param {HTMLElement} element 
     * @param {html} html
     * 
     * @return void
     */
    const showHoveredBox = function (element, html, event) {
        // Don't show hover box if navigation alert is visible
        if (JVisualCSS.isNavigationAlertVisible()) {
            return;
        }

        let rect = element.getBoundingClientRect();

        // Get the iframe position relative to the parent document
        let iframeRect = { left: 0, top: 0 };

        if (iframe) {
            iframeRect = iframe.getBoundingClientRect();
        }
        
        // Is this the same element we're already in 'currently editing' state? Skip hovered box...
        if (element.hasAttribute('data-jvisualcss-current') 
            && element.getAttribute('data-jvisualcss-current') === 'true') {
            console.log("STOP! It's active...");
            return;
        }

        // Remove previous box if exists
        document.getElementById('jvisual-css-hovered-box')?.remove();

        // Create a new box
        const newBox = document.createElement('div');
        newBox.id = 'jvisual-css-hovered-box';

        const innerWrapper = document.createElement('div');
        innerWrapper.classList.add('jvisual-css-hovered-box__inner');

        // Style the new box
        const minSize = 40; // Minimum size needed for edit button
        const isSmall = rect.width < minSize || rect.height < minSize;
        
        Object.assign(newBox.style, {
            width: `${rect.width + 10}px`,
            height: `${rect.height + 10}px`,
            left: `${rect.x + iframeRect.left + window.scrollX - 5}px`, // Adjust for scrolling
            top: `${rect.y + iframeRect.top + window.scrollY -5}px`,  // Adjust for scrolling
        });

        if (isSmall) {
            newBox.classList.add('jvisual-css-hovered-box--small');
        }

        // Create the edit button
        const editButton = document.createElement('button');
        editButton.innerHTML = `<span class="icon-paint-brush"></span> <strong>&lt;${element.tagName.toLowerCase()}&gt;</strong>`;
        editButton.classList.add('btn', 'btn-secondary', 'btn-sm');

        editButton.addEventListener('click', function () {
             //console.log('click editButton!');
            showElementCss(html);
            changeCurEditAttr(element, true);
        
            // Accessing the newBox and change to 'currently editing' state
            const parentDiv = editButton.closest('#jvisual-css-hovered-box');
            if (parentDiv) {
                // Delete if exists
                document.getElementById('jvisual-css-hovered-box--currently-editing')?.remove();
                
                parentDiv.id = 'jvisual-css-hovered-box--currently-editing';
                this.disabled = true;
                //this.innerHTML = 'Currently customizing...'        
            }
        });   

        newBox.appendChild(innerWrapper);
        innerWrapper.appendChild(editButton);

        document.body.appendChild(newBox);

        //console.log('showHoveredBox', rect, newBox);
        //console.log('iframe', iframe, iframeRect);

        // Get the cursor's X position from the event
        const cursorX = event.clientX;
        
        // Get screen distance between the left and element
        const distanceFromLeftEdge = element.getBoundingClientRect().left;

        // Get the current window's scroll position
        // Get iframe's scroll position
        const iframeScrollX = iframe.contentWindow.scrollX;

        // Find the specific parent element of editButton
        const parentElement = editButton.closest('.jvisual-css-hovered-box__inner');

        // Set the parent element's left position to match the cursor's X position
        if (parentElement) {
            parentElement.style.left = `${cursorX + iframeScrollX - distanceFromLeftEdge}px`; // Position the parent at cursor X + scroll position
        }

        //console.log('cursorX', cursorX, element, iframeScrollX, distanceFromLeftEdge);

        // Update position method inside the iframe
        const updateHoveredBoxPosition = function () {
            rect = element.getBoundingClientRect();
            iframeRect = iframe.getBoundingClientRect();
            Object.assign(newBox.style, {
                width: `${rect.width + 10}px`,
                height: `${rect.height + 10}px`,
                left: `${rect.x + iframeRect.left + window.scrollX - 5}px`, // Adjust for scrolling
                top: `${rect.y + iframeRect.top + window.scrollY -5}px`,  // Adjust for scrolling
            });
        };

        // Initial position setup
        updateHoveredBoxPosition();

        // Add event listeners for scroll and resize inside the iframe's window
        iframe.contentWindow.addEventListener('scroll', updateHoveredBoxPosition);
        iframe.contentWindow.addEventListener('resize', updateHoveredBoxPosition);

        // Observe changes in the element's size using ResizeObserver
        const resizeObserver = new ResizeObserver(updateHoveredBoxPosition);
        resizeObserver.observe(element);

        // Cleanup event listeners when the box is removed
        newBox.addEventListener('DOMNodeRemoved', function () {
            iframe.contentWindow.removeEventListener('scroll', updateHoveredBoxPosition);
            iframe.contentWindow.removeEventListener('resize', updateHoveredBoxPosition);
            resizeObserver.disconnect();
        });
    }

    /**
     * Display the hovered element's CSS configuration HTML form
     * 
     * @param {html} html 
     */
    const showElementCss = function (html) {
        console.log('Showing element CSS');
        controls.innerHTML = html;

        setTimeout(() => {
            console.log('Looking for color pickers...');
            const colorPickers = controls.querySelectorAll('.color-picker-wrapper');
            console.log('Found color pickers:', colorPickers.length);
            
            // Reset color storage
            window.pickrInstances = {};

            colorPickers.forEach(wrapper => {
                console.log('Initializing picker for:', wrapper);
                initColorPicker(wrapper);
            });
        }, 0);
    }

    /**
     * Remove/reset a CSS property
     * 
     * @since 0.0.6
     */
    const removeCssProp = function (el) {
        const property = el.getAttribute('data-property');
        const selector = document.getElementById('jvisualcss-data-selector').value;

        let existing = all_css.find(item => item.selector === selector);
        if (existing) {
            // Remove from saved_css
            delete existing.properties[property];
            saved_css.value = JSON.stringify(all_css, null, 0);
            console.log(`'${property}' removed'`, el);

            // Update CSS in iframe's head
            addStyleTag(existing);

            // Reset input/select/color field
            const field = document.querySelector(`.jvisual-css-field-edit[data-property="${property}"]`);
            const type = field.getAttribute('data-type');
            
            if (type === 'color') {
                const pickrInstance = window.pickrInstances[property];
                field.value = 'rgba(255,255,255,0)';

                if (pickrInstance) {
                    pickrInstance.setColor(null, true); // Reset without triggering events
                }
            } else {
                field.value = '';
            }
        } else {
            console.log(`No property '${property}' found!`);
        }
    }

    /**
     * Target remove/reset button
     */
    document.addEventListener('click', function (event) {
        if (event.target.classList.contains('jvisual-css--remove-property')) {
            event.preventDefault();
            console.log('click on reset!!!!');
            removeCssProp(event.target);
        }
    });

    /**
     * Add data-jvisualcss-current with false as default value 
     * (aka. element is not currently being edited)
     * 
     * @param {HTMLElement} element 
     * 
     * @return void
     */
    const addCurEditAttr = function (element) {
        //console.log('data-hovered', element);
        if (!element.hasAttribute('data-jvisualcss-current')) {
            element.setAttribute('data-jvisualcss-current', false);
        } else {
            //console.log('attr already exists!');
        }
    }

    /**
     * Change data-jvisualcss-current value. 
     * 
     * @param {HTMLElement} element 
     * @param {bool} value              false = element is NOT currently being edited
     *                                  true = element IS currently being edited
     * 
     * @return void
     */
    const changeCurEditAttr = function (element, value) {
        // Remove all instances of data-jvisualcss-current attributes
        var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
        iframeDocument.querySelectorAll("[data-jvisualcss-current]").forEach(el => {
            //console.log('esto', el);
            el.removeAttribute("data-jvisualcss-current");
        });
        element.setAttribute('data-jvisualcss-current', value);
    }

    /**
     * Take a CSS selector and convert into a valid html ID attribute's value
     * 
     * @param {string} selector 
     * 
     * @returns 
     */
    const selectorToId = function (selector) {
        return selector
            .replace(/\s*>\s*/g, '__gt__')  // Replace '>' with '__gt__'
            .replace(/\./g, '__dot__')      // Replace '.' with '__dot__'
            .replace(/\s+/g, '__sp__')      // Replace spaces with '__sp__'
            .replace(/\[/g, '__lb__')       // Replace '[' with '__lb__'
            .replace(/\]/g, '__rb__')       // Replace ']' with '__rb__'
            .replace(/#/g, '__hash__');     // Replace '#' with '__hash__'
    }

    /**
     * Take an html ID attribute's value and convert into a valid CSS selector
     * 
     * @param {string} id This id is generated from  selectorToId()
     * 
     * @returns 
     */
    const idToSelector = function (id) {
        return id
            .replace(/__gt__/g, ' > ')      // Convert '__gt__' back to '>'
            .replace(/__dot__/g, '.')       // Convert '__dot__' back to '.'
            .replace(/__sp__/g, ' ')        // Convert '__sp__' back to space
            .replace(/__lb__/g, '[')        // Convert '__lb__' back to '['
            .replace(/__rb__/g, ']')        // Convert '__rb__' back to ']'
            .replace(/__hash__/g, '#');     // Convert '__hash__' back to '#'
    }

    /**
     * 
     * @param {string} selector 
     * @param {object} data 
     * @returns 
     */
    const addStyleTag = function (data) {
        const cssContent = getCSSFromObj(data);

        console.log('style tag', data, cssContent);

        if (!iframe || !iframe.contentDocument) return;

        const iframeHead = iframe.contentDocument.head;
        if (!iframeHead) return;

        const styleId = selectorToId(data.selector);

        // Check if style already exists
        let existingStyle = iframeHead.querySelector(`#${styleId}`);
        if (existingStyle) {
            existingStyle.remove();
        }

        // Create new style element
        let styleElement = document.createElement('style');
        styleElement.id = styleId;
        styleElement.textContent = cssContent;

        // Append style to iframe's head
        iframeHead.appendChild(styleElement);
    }

    /**
     * Extract the properties from an object and convert into valid CSS
     * 
     * @param {object} obj 
     * 
     * @returns 
     */
    const getCSSFromObj = function (obj) {
        const { selector, properties } = obj;
    
        //console.log('getCSSFromObj', obj);

        // Convert properties into valid CSS strings
        const cssProperties = Object.entries(properties)
            .map(([prop, value]) => {

                let formattedValue = '';

                if ('t' in value 
                    && 'r' in value 
                    && 'b' in value 
                    && 'l' in value
                    && 'metric' in value
                ) {
                    // t+metric r+metric b+metric l+metric. e.g. '10px 10px 10px 10px' (it supports 'auto' too)
                    formattedValue += adjustFlexibleValue(value.t, value.metric) + ' ';
                    formattedValue += adjustFlexibleValue(value.r, value.metric) + ' ';
                    formattedValue += adjustFlexibleValue(value.b, value.metric) + ' ';
                    formattedValue += adjustFlexibleValue(value.l, value.metric);
                } else if ('base' in value 
                    && 'metric' in value
                ) {
                    
                    // Check if the metric is a special value. e.g. 'auto
                    if (specialValues.includes(value.metric)) {
                        console.log('special value', value.base, value.metric);
                        // Only include metric and skip base. e.g. 'auto'
                        formattedValue = value.metric;
                    } else {
                        console.log('NON special value', value.base, value.metric);
                        // base + metric. e.g. '10px'
                        formattedValue = `${value.base}${value.metric}`;
                    }
                } else if ('base' in value) {
                    // value. e.g. '10'
                    formattedValue = value.base;
                } else {
                    // Nothing to do here
                }

                return formattedValue.length > 0 ? `${prop}: ${formattedValue};` : '';
            })
            .join(' ');
    
        return `${selector} { ${cssProperties} }`;
    }

    /**
     * Formats the values based on whether they are 'auto' or not.
     * 
     * @param {Object} value - The value with or without metric. e.g. '10' or 'auto'
     * @param {string} metric - The metric to append to the values. e.g. 'px'
     * 
     * @returns {string} - The formatted string without empty spaces
     */
    adjustFlexibleValue = function (value, metric) {
        return value && value.trim() !== 'auto' ? Number(value) + metric : value;
    }

    //console.log('all_css init', all_css);

    controls.innerHTML = '<div class="alert alert-info">Select an element from the site on the right to start customizing the design.</div>';

    iframe.addEventListener('load', function() {
        try {
            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            
            // Prevent default click behavior on all links
            iframeDoc.addEventListener('click', function(e) {
                if (e.target.tagName === 'A' || e.target.closest('a')) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Optionally: Extract the path and update the navigation input
                    const link = e.target.closest('a');
                    if (link && link.href) {
                        const baseUrl = document.getElementById('preview-site-path').dataset.baseUrl;
                        const path = link.href.replace(baseUrl, '');
                        
                        // Update the path input and trigger the change event
                        const pathInput = document.getElementById('preview-site-path');
                        pathInput.value = path;
                        pathInput.dispatchEvent(new Event('change'));
                    }
                }
            }, true);
            
            // Prevent form submissions
            iframeDoc.addEventListener('submit', function(e) {
                e.preventDefault();
                e.stopPropagation();
            }, true);
            
            iframeDoc.querySelectorAll('body *').forEach(function(el) {
                el.addEventListener('mouseover', function(event) {
                    const hovered = event.target;
                    const tagName = hovered.tagName.toLowerCase(); // e.g. 'div', 'p'
                    let computedValue = null;
                    let rawValue = null;

                    //console.log('test', hovered, el);
                    //console.log(tagName, el.tagName.toLowerCase())

                    if (tags.hasOwnProperty(tagName)) {
                        const computedStyles = window.getComputedStyle(hovered); // Get the hovered's CSS
                        const selector = cssSelector(hovered);
                        let cssProperties = [];
                        let output = `<p>Customize design for <strong>&lt;${tagName}&gt;</strong> tag</p><hr>`;
                        //let output = ''
                        output += processCssSelector(hovered);

                        // Extract CSS properties
                        for (let i = 0; i < tags[tagName].length; i++) {
                            let property = tags[tagName][i]; // 'color', 'background', 'border-width', etc.
                            const type = properties[property]['type']; // 'number', 'color', 'multiple', etc.
                            const label = properties[property]['label']; // 'Border width'
                            
                            if (type === 'multiple') {
                                const props = properties[property]['properties'];
                                //var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;

                                output += elementLayoutHeader(property, label);
                                
                                // Multiple properties. e.g. for margin: 0 80px 11px 0 but expresed as:
                                //                      border-top-width: 0
                                //                      border-left-width: 80px
                                //                      border-right-width: 11px
                                //                      border-bottom-width: 0
                                props.forEach(function(key) {
                                    //console.log('test 1', jss.getAll(selector, iframeDocument));
                                    computedValue = computedStyles.getPropertyValue(key); // e.g., 16px
                                    rawValue = hovered.style[key] || computedValue; // Actual CSS value
                                    output += processCssProp(key, computedValue, selector);
                                    cssProperties.push(`${key}: ${rawValue}`);
                                });
                            } else {
                                computedValue = computedStyles.getPropertyValue(property); // e.g., 16px
                                rawValue = hovered.style[property] || computedValue; // Actual CSS value

                                // Single property with its value. e.g. color: #fff
                                output += processCssProp(property, computedValue);
                                //output += `${property}: ${rawValue}<br>`;

                                cssProperties.push(`${property}: ${rawValue}`);
                            }

                            
                        }

                        //console.log(tagName, tags[tagName], cssProperties);

                        addCurEditAttr(hovered);
                        showHoveredBox(hovered, output, event);
                        //showElementCss(output);

                        //hovered.style.boxShadow = '0 2px 0 blue inset, 0 -2px 0 blue inset, 2px 0 0 blue inset, -2px 0 0 blue inset';
                    }
                });

                el.addEventListener('mouseout', function(e) {
                    //e.target.style.boxShadow = '';
                });
            });
        } catch (error) {
            console.warn('Could not access iframe content due to same-origin policy', error);
        }
    });

    controls.addEventListener('change', function(event) {
        if (event.target.matches('input, select')) {
            const selector = document.getElementById('jvisualcss-data-selector').value;
            const el = event.target;
            const property = el.getAttribute('data-property')
            const name = el.getAttribute('name');
            //let value = el.value;

            // Get all data associated to el such as metric
            const inputs = document.querySelectorAll(`[name^="jvisualcss_property[${property}]"]`);
            const values = {};

            inputs.forEach(input => {
                const regex = new RegExp(`^jvisualcss_property\\[${property}\\]`);
                const name = input.name.replace(regex, ''); // Remove base name

                if (!name) {
                    values.base = input.value; // Direct value if no further nesting
                } else {
                    const key = name.replace(/\[|\]/g, ''); // Extract key inside brackets
                    values[key] = input.value;
                }
            });

            // Merge into all the existing custom CSS
            let existing = all_css.find(item => item.selector === selector);
            if (existing) {
                existing.properties[[property]] = values;
            } else {
                all_css.push({
                    selector: selector,
                    properties: {
                        [[property]]: values
                    }
                });
            }

            saved_css.value = JSON.stringify(all_css, null, 0);

            // Inject CSS in iframe's head
            const obj_by_selector = all_css.find(item => item.selector === selector);
            addStyleTag(obj_by_selector);

            //console.log('all_css changed!', all_css, saved_css.value);
            if (event.target.matches('select')) {
                const inputElement = document.querySelector(`[data-property="${property}"]`);
                console.log('select', event.target, el.value, property, inputElement);
                if (specialValues.includes(el.value)) {
                    inputElement.disabled = true;
                } else {
                    inputElement.disabled = false;
                }
            }
        }
    });

    // Add Pickr initialization
    const initColorPicker = function(wrapper) {
        const input = wrapper.querySelector('.color-picker-input');
        const button = wrapper.querySelector('.color-picker-button');

        if (!input || !button) {
            console.log('Missing elements for color picker');
            return;
        }

        const pickr = Pickr.create({
            el: button,
            theme: 'nano',
            defaultRepresentation: 'RGBA',
            default: input.value || '#000000',
            components: {
                preview: true,
                opacity: true,
                hue: true,
                interaction: {
                    hex: false,
                    rgba: true,
                    input: true,
                    clear: true,
                    save: true
                }
            }
        });

        // Apply color on change
        pickr.on('change', (color) => {
            if (color) {
                const rgba = color.toRGBA().toString(0);
                input.value = rgba; // Update the input value
                button.style.backgroundColor = rgba; // Update the button color

                // Trigger change event
                const event = new Event('change', { bubbles: true });
                input.dispatchEvent(event);

                // Save the color immediately
                console.log('Color saved:', rgba); // You can add additional logic here to save the color
                // Optionally, you can call a function to handle saving the color to your application state or backend
            }
        });

        // Handle the save event from the Pickr (if you still want to keep this functionality)
        pickr.on('save', (color) => {
            const rgba = color.toRGBA().toString(0);
            input.value = rgba; // Save the color to the input
            button.style.backgroundColor = rgba; // Update the button color
            pickr.hide(); // Close the color picker popup
        });

        // Store the instance using the input element as the key
        window.pickrInstances[input.getAttribute('data-property')] = pickr;
    }

    const pathInput = document.getElementById('preview-site-path');
    if (pathInput) {
        // Store initial path
        JVisualCSS.currentPath = pathInput.value;
        
        pathInput.addEventListener('change', function() {
            JVisualCSS.pendingPath = this.value.trim();
            document.getElementById('save-alert').classList.remove('d-none');
            JVisualCSS.toggleIframeOverlay(true);
            // Remove any existing hover box when alert appears
            document.getElementById('jvisual-css-hovered-box')?.remove();
            document.getElementById('jvisual-css-hovered-box--currently-editing')?.remove();
        });
    }
});

JVisualCSS.cancelNavigation = function() {
    const pathInput = document.getElementById('preview-site-path');
    pathInput.value = JVisualCSS.currentPath;
    document.getElementById('save-alert').classList.add('d-none');
    JVisualCSS.toggleIframeOverlay(false); // Hide overlay
};

JVisualCSS.proceedWithNavigation = function() {
    const pathInput = document.getElementById('preview-site-path');
    const basePath = pathInput.dataset.baseUrl;
    // Remove leading slash if exists
    const cleanPath = JVisualCSS.pendingPath.replace(/^\/+/, '');
    const iframe = document.getElementById('preview-site-edit-iframe');
    iframe.src = basePath + cleanPath;
    // Update current path after successful navigation
    JVisualCSS.currentPath = JVisualCSS.pendingPath;
    document.getElementById('save-alert').classList.add('d-none');
    JVisualCSS.toggleIframeOverlay(false); // Hide overlay
};