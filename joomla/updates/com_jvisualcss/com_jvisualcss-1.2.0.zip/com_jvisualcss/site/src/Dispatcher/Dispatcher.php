<?php
/**
 * @version    CVS: 0.0.1
 * @package    Com_Jvisualcss
 * @author     htmgarcia <htmgarcia@gmail.com>
 * @copyright  2025 htmgarcia
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jvisualcss\Component\Jvisualcss\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\ComponentDispatcher;
use Joomla\CMS\Language\Text;

/**
 * ComponentDispatcher class for Com_Jvisualcss
 *
 * @since  0.0.1
 */
class Dispatcher extends ComponentDispatcher
{
	/**
	 * Dispatch a controller task. Redirecting the user if appropriate.
	 *
	 * @return  void
	 *
	 * @since   0.0.1
	 */
	public function dispatch()
	{
		parent::dispatch();
	}
}
