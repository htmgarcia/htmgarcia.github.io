<?php
/**
 * @version    CVS: 0.0.1
 * @package    Com_Jvisualcss
 * @author     htmgarcia <htmgarcia@gmail.com>
 * @copyright  2025 htmgarcia
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jvisualcss\Component\Jvisualcss\Api\View\XXX_UCFIRST_INTERNAL_NAME_XXX;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\JsonApiView as BaseApiView;

/**
 * The XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXX view
 *
 * @since  0.0.1
 */
class JsonApiView extends BaseApiView
{
	/**
	 * The fields to render item in the documents
	 *
	 * @var    array
	 * @since  0.0.1
	 */
	protected $fieldsToRenderItem = [
		//XXX_FIELDS_TO_RENDER_ITEM
	];

	/**
	 * The fields to render items in the documents
	 *
	 * @var    array
	 * @since  0.0.1
	 */
	protected $fieldsToRenderList = [
		//XXX_FIELDS_TO_RENDER_LIST
	];
}