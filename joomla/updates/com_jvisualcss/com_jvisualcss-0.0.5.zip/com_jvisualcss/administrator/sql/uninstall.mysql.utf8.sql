DROP TABLE IF EXISTS `#__jvisualcss_items`;
