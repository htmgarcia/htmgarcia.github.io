<?php
/**
 * @version    CVS: 0.0.1
 * @package    Com_Jvisualcss
 * @author     htmgarcia <htmgarcia@gmail.com>
 * @copyright  2025 htmgarcia
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
namespace Jvisualcss\Component\Jvisualcss\Api\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\ApiController;

/**
 * The XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXX controller
 *
 * @since  0.0.1
 */
class XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXXController extends ApiController 
{
	/**
	 * The content type of the item.
	 *
	 * @var    string
	 * @since  0.0.1
	 */
	protected $contentType = 'XXX_INTERNAL_NAME_FORCE_LIST_XXX';

	/**
	 * The default view for the display method.
	 *
	 * @var    string
	 * @since  0.0.1
	 */
	protected $default_view = 'XXX_INTERNAL_NAME_FORCE_LIST_XXX';
}