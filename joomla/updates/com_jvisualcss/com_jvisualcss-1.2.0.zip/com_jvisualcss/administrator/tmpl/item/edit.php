<?php
/**
 * @version    CVS: 0.0.1
 * @package    Com_Jvisualcss
 * @author     htmgarcia <htmgarcia@gmail.com>
 * @copyright  2025 htmgarcia
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;

$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate');
HTMLHelper::_('bootstrap.tooltip');

$wa->useStyle('com_jvisualcss.pickr')
	->useScript('com_jvisualcss.pickr');
	
$wa->useStyle('com_jvisualcss.editor')
    ->useScript('com_jvisualcss.editor');

if ( file_exists( __DIR__ . '/_pro.php' ) ) {
	require_once __DIR__ . '/_pro.php';
}
?>

<form
	action="<?php echo Route::_('index.php?option=com_jvisualcss&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="item-form" class="form-validate form-horizontal">

	
	<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'item')); ?>
	<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'item', Text::_('COM_JVISUALCSS_TAB_ITEM', true)); ?>
	<div class="row-fluid">
		<div class="col-md-12 form-horizontal">
			<div id="jvisual-css-editor"></div>
			<fieldset class="adminform">
				<legend><?php echo Text::_('COM_JVISUALCSS_FIELDSET_ITEM'); ?></legend>
				<div style="display: none;">
					<?php echo $this->form->renderField('created_by'); ?>
					<?php echo $this->form->renderField('modified_by'); ?>
					<?php echo $this->form->renderField('css'); ?>
				</div>
				<hr>
				<?php echo $this->form->renderField('title'); ?>
				<?php echo $this->form->renderField('default'); ?>
				<div>Check this box to apply this style in frontend</div>
			</fieldset>
		</div>
	</div>
	<?php echo HTMLHelper::_('uitab.endTab'); ?>
	<input type="hidden" name="jform[id]" value="<?php echo isset($this->item->id) ? $this->item->id : ''; ?>" />


	
	<?php echo HTMLHelper::_('uitab.endTabSet'); ?>

	<input type="hidden" name="task" value=""/>
	<?php echo HTMLHelper::_('form.token'); ?>

</form>

<div id="preview-site-edit">
	<div class="input-group mb-3">
		<span class="input-group-text" style="margin-left: 10px; background: #ccc; color: #555; border-color: #999; font-size: 0.9em;"><?php echo Uri::root(); ?></span>
		<input type="text" class="form-control" id="preview-site-path" placeholder="path/to/page" data-base-url="<?php echo Uri::root(); ?>">
	</div>
	<div id="save-alert" class="alert alert-warning d-none" style="margin-left: 10px; z-index: 9999;">
		<div class="mb-3">Please save your changes before navigating to a different page to prevent losing your work.</div>
		<button class="btn btn-primary me-2" onclick="Joomla.submitbutton('item.apply')">Save Changes</button>
		<button class="btn btn-secondary me-2" onclick="JVisualCSS.proceedWithNavigation()">I Already Saved</button>
		<button class="btn btn-danger" onclick="JVisualCSS.cancelNavigation()">Cancel</button>
	</div>
	<iframe src="<?php echo Uri::root() ?>" id="preview-site-edit-iframe"></iframe>
</div>

<script>
let pendingPath = '';

document.getElementById('preview-site-path').addEventListener('change', function() {
	pendingPath = this.value.trim();
	document.getElementById('save-alert').classList.remove('d-none');
});

function proceedWithNavigation() {
	const basePath = '<?php echo Uri::root(); ?>';
	// Remove leading slash if exists
	const cleanPath = pendingPath.replace(/^\/+/, '');
	const iframe = document.getElementById('preview-site-edit-iframe');
	iframe.src = basePath + cleanPath;
	document.getElementById('save-alert').classList.add('d-none');
}
</script>