<?php
defined('_JEXEC') or die;

use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

class JFormFieldHtmgarciaLicense extends FormField
{
    protected $type = 'htmgarcialicense';
 
    public function getInput()
    {
        // Ensure field ID is unique
        $fieldId   = $this->id;
        $fieldName = $this->name;
        $extension = (string) $this->element['extension'];

        // Get current value and decode JSON if multiple values are stored
        $value       = $this->value ?? [];

        $key         = $value['key'] ?? '';
        $instance_id = $value['instance_id'] ?? ''; 
        $status      = $value['status'] ?? '';   
        $date        = $value['date'] ?? '';        

        // Begin output buffer
        $output = '<div id="' . $fieldId . '_wrapper">';
        $output .= '<div class="license-entry mb-2">
            <input type="text" name="' . 
                $fieldName . '[key]" value="' . 
                $key . '" class="form-control d-inline-block" style="width: 50%;" data-htmgarcia-key="' . 
                $key . '"/>
            <input type="hidden" name="' . 
                $fieldName . '[instance_id]" value="' . 
                $instance_id . '"/>
            <input type="hidden" name="' . 
                $fieldName . '[status]" value="' . 
                $status . '"/>
            <button type="button" class="btn btn-primary btn-sm mx-1" data-htmgarcia-activate="' . 
                $extension . '">' . 
                Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_UPDATE_LICENSE') . 
                '</button>
            <span data-htmgarcia-status="' . 
                $extension . '"></span>
        </div>';
        $output .= '</div>';

        return $output;
    }
}
