<?php
/**
 * @version    CVS: 0.0.1
 * @package    Com_Jvisualcss
 * @author     htmgarcia <htmgarcia@gmail.com>
 * @copyright  2025 htmgarcia
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jvisualcss\Component\Jvisualcss\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;

/**
 * Items list controller class.
 *
 * @since  0.0.1
 */
class ItemsController extends AdminController
{
	/**
	 * Method to clone existing Items
	 *
	 * @return  void
	 *
	 * @throws  Exception
	 */
	public function duplicate()
	{
		// Check for request forgeries
		$this->checkToken();

		// Get id(s)
		$pks = $this->input->post->get('cid', array(), 'array');

		try
		{
			if (empty($pks))
			{
				throw new \Exception(Text::_('COM_JVISUALCSS_NO_ELEMENT_SELECTED'));
			}

			ArrayHelper::toInteger($pks);
			$model = $this->getModel();
			$model->duplicate($pks);
			$this->setMessage(Text::_('COM_JVISUALCSS_ITEMS_SUCCESS_DUPLICATED'));
		}
		catch (\Exception $e)
		{
			Factory::getApplication()->enqueueMessage($e->getMessage(), 'warning');
		}

		$this->setRedirect('index.php?option=com_jvisualcss&view=items');
	}

	/**
	 * Proxy for getModel.
	 *
	 * @param   string  $name    Optional. Model name
	 * @param   string  $prefix  Optional. Class prefix
	 * @param   array   $config  Optional. Configuration array for model
	 *
	 * @return  object	The Model
	 *
	 * @since   0.0.1
	 */
	public function getModel($name = 'Item', $prefix = 'Administrator', $config = array())
	{
		return parent::getModel($name, $prefix, array('ignore_request' => true));
	}



	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   0.0.1
	 *
	 * @throws  Exception
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$pks   = $this->input->post->get('cid', array(), 'array');
		$order = $this->input->post->get('order', array(), 'array');

		// Sanitize the input
		ArrayHelper::toInteger($pks);
		ArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return)
		{
			echo "1";
		}

		// Close the application
		Factory::getApplication()->close();
	}

	public function setDefault()
	{
		// Check for request forgeries
		$this->checkToken();

		$cid = $this->input->get('cid', array(), 'array');
		$id = (int) $cid[0];  // Get the first ID from the array

		if (!$id) {
			$this->setMessage(Text::_('COM_JVISUALCSS_NO_ITEM_SELECTED'), 'warning');
			$this->setRedirect(Route::_('index.php?option=com_jvisualcss&view=items', false));
			return;
		}

		$db = Factory::getContainer()->get('DatabaseDriver');

		try {
			// Reset all items to 0
			$query = $db->getQuery(true)
				->update($db->quoteName('#__jvisualcss_items'))
				->set($db->quoteName('default') . ' = ' . $db->quote(0));
			$db->setQuery($query);
			$db->execute();

			// Set the selected item to 1
			$query = $db->getQuery(true)
				->update($db->quoteName('#__jvisualcss_items'))
				->set($db->quoteName('default') . ' = ' . $db->quote(1))
				->where($db->quoteName('id') . ' = ' . $id);
			$db->setQuery($query);
			$result = $db->execute();

			if ($result) {
				$this->setMessage(Text::_('COM_JVISUALCSS_ITEM_SET_DEFAULT'));
			} else {
				$this->setMessage(Text::_('COM_JVISUALCSS_ITEM_SET_DEFAULT_ERROR'), 'error');
			}

		} catch (\Exception $e) {
			$this->setMessage($e->getMessage(), 'error');
		}

		$this->setRedirect(Route::_('index.php?option=com_jvisualcss&view=items', false));
	}
}
