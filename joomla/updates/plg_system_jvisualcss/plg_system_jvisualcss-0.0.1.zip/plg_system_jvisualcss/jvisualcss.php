<?php
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die('Restricted access');

/**
 * @since 0.0.1
 */
class PlgSystemJVisualCss extends CMSPlugin
{
    /**
     * Event method onBeforeCompileHead
     *
     * @since 0.0.1
     * 
     * @return void
     */
    public function onBeforeCompileHead()
    {
        $app = Factory::getApplication();
        $document = Factory::getDocument();
        $user = Factory::getUser();

        // Run only on frontend
        if (!$app->isClient('site'))
        {
            return;
        }

        $this->loadCss();
    }

    /**
     * Load custom CSS in <head>
     * 
     * @since 0.0.1
     * 
     * @return void
     */
    public function loadCss() {
        $db = \Joomla\CMS\Factory::getContainer()->get('DatabaseDriver');

        // Check if table exists
        $tables = $db->getTableList();
        $prefix = $db->getPrefix();
        $tableName = '#__jvisualcss_items';
        $tableWithoutPrefix = str_replace('#__', '', $tableName);
        $fullTableName = str_replace('#__', $prefix, $tableName);

        // Stop if table doesn't exist
        if (!in_array($fullTableName, $tables)) {
            return;
        }

        // Prepare the query
        $query = $db->getQuery(true)
            ->select($db->quoteName(['css']))
            ->from($db->quoteName($tableName))
            ->where($db->quoteName('default') . ' = 1');

        // Execute the query
        $db->setQuery($query);
        $result = $db->loadAssoc();

        if ($result && $result['css']) {
            $this->objToStyleTag($result['css']);
        }
    }

    /**
     * Convert db data to valid CSS
     * 
     * @since 0.0.1
     * 
     * @param object $jsonData
     * 
     * @return html formated <style> tags, one for each selector
     */
    public function objToStyleTag($jsonData) {
        $cssArray = json_decode($jsonData, true);

        /*echo '<pre>';
        print_r($cssArray);
        echo '</pre>';*/

        // Generate CSS styles
        $cssOutput = "";

        foreach ($cssArray as $cssItem) {
            $selector = $cssItem['selector'];
            $cssId = $this->selectorToId($selector); // Convert selector to valid ID

            $cssOutput .= "<style id=\"{$cssId}\">\n";

            // Generate CSS properties
            $cssProperties = [];
            foreach ($cssItem['properties'] as $prop => $value) {
                $formattedValue = isset($value['metric']) ? $value['base'] . $value['metric'] : $value['base'];
                $cssProperties[] = "{$prop}: {$formattedValue};";
            }

            // Combine into CSS block
            $cssOutput .= "{$selector} { " . implode(' ', $cssProperties) . " }\n";

            $cssOutput .= "</style>\n";
        }

        // Insert into <head>
        if (!empty($cssOutput)) {
            // Load CSS into Joomla's head
            $doc = Factory::getApplication()->getDocument();
            $doc->addCustomTag($cssOutput);
        }
    }

    /**
     * Convert selector to valid ID attribute's value
     * 
     * @since 0.0.1
     * 
     * @param string $selector Valid CSS selector
     * 
     * @return string 
     */
    public function selectorToId($selector) {
        return str_replace(
            [' > ', '.', ' ', '[', ']', '#'],  // Match these characters
            ['__gt__', '__dot__', '__sp__', '__lb__', '__rb__', '__hash__'], // Replace with these
            $selector
        );
    }

    public function setDefault()
    {
        // Check for request forgeries
        $this->checkToken();

        $id = $this->input->get('id', 0, 'int');
        $db = Factory::getContainer()->get('DatabaseDriver');

        try {
            // Reset all items to 0
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__jvisualcss_items'))
                ->set($db->quoteName('default') . ' = ' . $db->quote(0));
            $db->setQuery($query);
            $db->execute();

            // Set the selected item to 1
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__jvisualcss_items'))
                ->set($db->quoteName('default') . ' = ' . $db->quote(1))
                ->where($db->quoteName('id') . ' = ' . (int) $id);
            $db->setQuery($query);
            $db->execute();

            if ($db->getAffectedRows() > 0) {
                $this->setMessage(Text::_('COM_JVISUALCSS_ITEM_SET_DEFAULT'));
            }

        } catch (\Exception $e) {
            $this->setMessage($e->getMessage(), 'error');
        }

        $this->setRedirect(Route::_('index.php?option=com_jvisualcss&view=items', false));
    }
}
