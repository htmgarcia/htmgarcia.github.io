<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Language\Text;

class PlgSystemHtmgarcia_Licenses extends CMSPlugin
{
    protected $app;
    protected $rest_base = 'https://htmgarcia.com';
    protected $plugin_name = 'htmgarcia_licenses';
    protected $update_host = 'htmgarcia.github.io';

    public function onBeforeCompileHead()
    {
        // Only in admin
        if (!$this->app->isClient('administrator')) {
            return;
        }

        $uri = Uri::base(true);
        $input = $this->app->input;
        $option = $input->getCmd('option');
        $view   = $input->getCmd('view');

        // Only on plugin edit screen
        if ($option === 'com_plugins' && $view === 'plugin') {
            $document = Factory::getDocument();

            // Text strings
            $text = $this->textStrings();

            if ($document instanceof HtmlDocument) {
                $inlineJS = <<<JS
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-htmgarcia-activate]').forEach(function (el) {
        el.addEventListener('click', function () {
            const extension     = el.getAttribute('data-htmgarcia-activate');
            const key           = document.querySelector('[name=\"jform[params][' + extension + '][key]\"]');
            const instance_id   = document.querySelector('[name=\"jform[params][' + extension + '][instance_id]\"]');
            const deactivate    = document.querySelector('button[data-htmgarcia-deactivate=\"' + extension + '\"]');
            const hidden_status = document.querySelector('[name=\"jform[params][' + extension + '][status]\"]');
            const status        = document.querySelector('[data-htmgarcia-status=' + extension + ']');

            if (!key.value) {
                alert("{$text['enter_license_key']}");
                return;
            }

            if (instance_id.length == 0) {
                alert("{$text['instance_id_missing']}");
                return;
            }
            
            status.textContent = "{$text['connecting']}";

            fetch("{$uri}/index.php?option=com_ajax&plugin=htmgarcia_licenses&format=raw&group=system", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    key: key.value,
                    extension,
                    task: 'activate'
                })
            })
            .then(res => res.json())
            .then(res => {
                console.log(res);
                if (res.success && res.data.success) {
                    console.log('success',res);
                    if (typeof res.data?.data?.instance?.id !== 'undefined') {
                        instance_id.value = res.data.data.instance.id; // Update instance id hidden input
                    }
                    hidden_status.value = 'activated'; // Update status hidden input
                    status.textContent = '✅ ' + (res.data.message || "{$text['license_updated']}");
                } else {
                    status.textContent = '❌ ' + res.data.error;
                }
            })
            .catch((e) => {
                console.log('err...',e);
                status.textContent = '❌ ' + "{$text['request_failed']}";
                hidden_status.value = ''; // Update status hidden input
            });
        });
    });
});
JS;

                $document->addScriptDeclaration($inlineJS);
            }
        }
    }

    /**
     * Adjust download URL only if license key is valid
     */
    public function onInstallerBeforePackageDownload(&$url, &$headers)
    {
        $uri  = Uri::getInstance($url);
		$host = $uri->getHost();

        // This is not an htmgarcia extension
		if (strpos($host, $this->update_host) === false)
		{
			return true;
		}

        $vars    = $uri->getQuery(true); // eg 'name=mod_lorem&version=1.2.3'
        $name    = $vars['name'] ?? null; // e.g. mod_lorem
        $version = $vars['version'] ?? null; // e.g. '1.2.3'

        if (!$name || !$version) {
            return true;
        }

        // Get stored license data for $name
        $data    = $this->getStoredLicenses();
        $current = $this->getExtensionLicense($name);
       
        if (!isset($current['key']) || !isset($current['instance_id'])) {
            // License is missing or is not active
            $this->app->enqueueMessage('To be able to download updates via Joomla updater, you need a license key. <a href="' . Uri::base() . 'index.php?option=com_plugins&view=plugins&filter_search=Easy Digital Sales">Update License Key</a>.');
            return true;
        }

        // Validate license
        $validate = $this->validate($current['key'], $current['instance_id']);
        if (!$validate) {
            // License is not valid
            $this->app->enqueueMessage('License is not valid! <a href="' . Uri::base() . 'index.php?option=com_plugins&view=plugins&filter_search=Easy Digital Sales">Update License Key</a>.');
            return true;
        }
        
        // Get file data such as download URL and version
        $update = $this->getUpdate($current['key']);

        if ($update['success'] === false) {
            $this->app->enqueueMessage('There was a problem downloading the update file.');
            return true;
        }

        $url = $update['update']['download_link'];

        return true;
    }

    /**
     * Return all text strings 
     * 
     * return array
     */
    public function textStrings()
    {
        return array(
            'enter_license_key'   => Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_ENTER_LICENSE_KEY'),
            'instance_id_missing' => Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_INSTANCE_ID_MISSING'),
            'connecting'          => Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_CONNECTING'),
            'license_updated'     => Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_LICENSE_UPDATED'),
            'request_failed'      => Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_REQUEST_FAILED')
        );
    }

    public function onAjaxHtmgarcia_licenses()
    {
        $input     = Factory::getApplication()->input;
        $extension = $input->json->getString('extension');
        $key       = $input->json->getString('key');
        $task      = $input->json->getString('task');

        switch ($task) {
            default:
            case 'activate':
                return $this->ajaxActivate($extension, $key);
                break;
        }
    }

    public function ajaxActivate($extension, $key)
    {
        if (!$key || !$extension) {
            return new JsonResponse(null, Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_MISSING_KEY_OR_EXTENSION'), true);
        }

        $license_is_valid = false;

        // Check if instance id exists which likely means this license was previously activated
        // So no need to activate a new instance
        $item = $this->getExtensionLicense($extension);
        if (isset($item['instance_id']) && !empty($item['instance_id'])) {
            // instance id exists, let's validate license
            if ($this->validate($key, $item['instance_id']) === true) {
                return new JsonResponse(array(
                    'success'     => true, 
                    'message'     => 'License is active and valid!'
                ), true);
            }
        }

        // When reaching this point either: 
        // we are activating the license for the first time
        // or license was deactivated and we'll try to activate again
        $domain = parse_url(Uri::root(), PHP_URL_HOST);

        // Contact remote API
        $url = $this->rest_base . '/wp-json/eds/v1/activate_license?key='
            . urlencode($key)
            . '&instance_name='
            . urlencode($domain);

        // Get Joomla HTTP client
        $options = array(
            'timeout' => 10, // seconds
        );
        $http = HttpFactory::getHttp($options);

        try {
            $response = $http->get($url);
            $data = json_decode($response->body, true);

            if ($response->code === 200) {
                $storeInDb = $this->storeInDb(array(
                    'extension'   => $extension, 
                    'key'         => $key, 
                    'instance_id' => $data['data']['instance']['id'],
                    'status'      => 'activated'
                ));

                if (!$storeInDb) {
                    return new JsonResponse(null, Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_PROBLEM_STORING_IN_DB'), true);
                }

                return new JsonResponse($data, true);
            }

            $storeInDb = $this->storeInDb(array(
                'extension'   => $extension, 
                'key'         => $key, 
                'instance_id' => '',
                'status'      => '' // Reset means there was a problem
            ));

            if (!$storeInDb) {
                return new JsonResponse(null, Text::_('PLG_SYSTEM_HTMGARCIA_LICENSES_PROBLEM_STORING_IN_DB'), true);
            }

            return new JsonResponse($data, true);
        } catch (\Exception $e) {
            return new JsonResponse(null, $e->getMessage(), true);
        }
    }

    /**
     * Get latest file update
     * 
     * @param string $key License key
     * 
     * @return array|bool - If false, we couldn't return update
     */
    public function getUpdate($key)
    {
        if (!$key) {
            return false;
        }

        // Contact remote API
        $url = $this->rest_base . '/wp-json/eds/v1/update?key=' . urlencode($key);

        // Get Joomla HTTP client
        $options = array(
            'timeout' => 10, // seconds
        );
        $http = HttpFactory::getHttp($options);

        try {
            $response = $http->get($url);

            if ($response->code === 200) {
                return json_decode($response->body, true);
            }

            // Couldn't return latest update data
            return false;
        } catch (\Exception $e) {
            // We don't return error. We just need a boolean
            return false;
        }
    }

    /**
     * Validate license
     * 
     * @param string $key           License key
     * @param string $instance_id   Instance id linked to license key
     * 
     * @return bool - If true: license is valid
     */
    public function validate($key, $instance_id)
    {
        if (!$key || !$instance_id) {
            return false;
        }

        // Contact remote API
        $url = $this->rest_base . '/wp-json/eds/v1/validate_license?key='
            . urlencode($key)
            . '&instance_id='
            . urlencode($instance_id);

        // Get Joomla HTTP client
        $options = array(
            'timeout' => 10, // seconds
        );
        $http = HttpFactory::getHttp($options);

        try {
            $response = $http->get($url);
            $data = json_decode($response->body, true);

            if ($response->code === 200) {
                // If true, license was previously activated and valid
                return $data['success'] ?? false;
            }

            // License is not valid
            return false;
        } catch (\Exception $e) {
            // We don't return error. We just need a boolean
            return false;
        }
    }

    public function onContentPrepareForm(Form $form, $data)
    {
        // Only apply to plugin's own config form
        if ($form->getName() !== 'com_plugins.plugin') {
            return;
        }

        // Make sure the custom form field is registered
        \JLoader::register('JFormFieldHtmgarciaLicense', __DIR__ . '/fields/htmgarcialicense.php');
    }

    /**
     * Update license data in db #_extension table (e.g. on activation/deactivation)
     * 
     * @param array $data array('extension' => 'mod_lorem', 'key' => 'XXXX', 'instance_id' => 'xxxx')
     * 
     * @return bool. true = all good. false = something went wrong
     */
    public function storeInDb($data) {
        $extensionId = $this->app->input->getInt('extension_id');

        if (!isset($data['extension']) 
            || !isset($data['key']) 
            || !isset($data['instance_id']) 
            || !isset($data['status']) 
            || $extensionId
        ) {
            return false;
        }
        
        try {
            $db = Factory::getDbo();

            // Get current value from params column
            $paramsJson = $this->getStoredLicenses();

            // Decode params into array
            $params = json_decode($paramsJson, true);
            if (!is_array($params)) {
                $params = []; // If empty or invalid JSON, start fresh
            }

            // Update only the target extension keys and instance id
            $params[$data['extension']] = array(
                'key'         => $data['key'],
                'instance_id' => $data['instance_id'],
                'status'      => $data['status']
            );

            // Encode back to JSON
            $newParamsJson = json_encode($params);

            // Update params column
            $update = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($newParamsJson))
                ->where($db->quoteName('element') . ' = ' . $db->quote($this->plugin_name));

            $db->setQuery($update);

            try {
                $db->execute();
            } catch (\RuntimeException $e) {
                return false;
            }

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get the stored licenses in plugins record in #_extensions db table
     * 
     * @return string - json format (not valid to process; still requires json_decode())
     */
    public function getStoredLicenses()
    {
        $db = Factory::getDbo();

        // Get current value from params column
        $query = $db->getQuery(true)
            ->select($db->quoteName('params'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('element') . ' = ' . $db->quote($this->plugin_name));

        $db->setQuery($query);
        $paramsJson = $db->loadResult();

        return $paramsJson;
    }

    /**
     * Get the stored licenses in plugins record in #_extensions db table for a given extension
     * 
     * @param string $extension e.g. 'mod_lorem'
     * 
     * @return array - license data: key, instance_id and status 
     */
    public function getExtensionLicense($extension)
    {
        $paramsJson = $this->getStoredLicenses();
        $data       = json_decode($paramsJson, true);

        return $data[$extension] ?? false;
    }
}
