<?php
/**
 * @autor       Valentin Garcia
 * @website     htmgarcia.com
 * @package     Joomla.Site
 * @subpackage  mod_multi_layouts
 * @copyright   Copyright (C) 2022 Valentin Garcia. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $app->getDocument()->getWebAssetManager();
$wa->registerAndUseStyle(
	'mod_modules.vg-isotope-grid', 
	'mod_multi_layouts/grid.css'
);

// Isotope
$wa->registerAndUseScript(
    'mod_modules.vg-isotope-grid',
    'mod_multi_layouts/isotope.pkgd.min.js',
    [],
    ['defer' => true]
);

// Isotope init
$wa->registerAndUseScript(
    'mod_modules.vg-isotope-init',
    'mod_multi_layouts/grid.js',
    [],
    ['defer' => true]
);

if (!$list)
{
	return;
}

// Categories
$categories = [];
foreach($list as $item) {
	array_push($categories, $item->category_title);
}
$categories = array_unique($categories);

// Class suffix
$moduleclass_sfx = $params->get('moduleclass_sfx', '');
?>
<div class="multilayouts-grid <?php echo $moduleclass_sfx ?>" data-grid="masonry-columns" data-cols="6">
	<div data-filters>
		<button class="is-checked" data-filter="*">
			<?php echo JText::_('MOD_MULTI_LAYOUTS_ALL') ?>
		</button>

		<?php foreach($categories as $category) { ?>
			<button class="button" data-filter=".category-<?php 
				echo str_replace(' ', '-', strtolower($category)) ?>"><?php 
					echo $category ?>
			</button>
		<?php } ?>

	</div>
	<div class="multilayouts-grid--items">
		<?php
		foreach($list as $item) {
			require ModuleHelper::getLayoutPath('mod_multi_layouts', '_grid-item');
		} 
		?>
	</div>
</div>