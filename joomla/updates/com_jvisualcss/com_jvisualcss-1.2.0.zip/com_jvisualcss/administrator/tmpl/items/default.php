<?php
/**
 * @version    CVS: 0.0.1
 * @package    Com_Jvisualcss
 * @author     htmgarcia <htmgarcia@gmail.com>
 * @copyright  2025 htmgarcia
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;


use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');

// Import CSS
$wa =  $this->document->getWebAssetManager();
$wa->useStyle('com_jvisualcss.admin')
    ->useScript('com_jvisualcss.admin');

$user      = Factory::getApplication()->getIdentity();
$userId    = $user->get('id');
$listOrder = $this->state->get('list.ordering');
$listDirn  = $this->state->get('list.direction');
$canOrder  = $user->authorise('core.edit.state', 'com_jvisualcss');



if (!empty($saveOrder))
{
	$saveOrderingUrl = 'index.php?option=com_jvisualcss&task=items.saveOrderAjax&tmpl=component&' . Session::getFormToken() . '=1';
	HTMLHelper::_('draggablelist.draggable');
}

?>

<form action="<?php echo Route::_('index.php?option=com_jvisualcss&view=items'); ?>" method="post"
	  name="adminForm" id="adminForm">
	<div class="row">
		<div class="col-md-12">
			<div id="j-main-container" class="j-main-container">
				<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>
				<?php if (empty($this->items)) : ?>
                    <div class="alert alert-info">
                        <span class="icon-info-circle" aria-hidden="true"></span><span class="visually-hidden"><?php echo Text::_('INFO'); ?></span>
                        <?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
                    </div>
                <?php else : ?>
					<div class="clearfix"></div>
					<table class="table table-striped" id="itemList">
						<thead>
						<tr>
							<th class="w-1 text-center">
								<input type="checkbox" autocomplete="off" class="form-check-input" name="checkall-toggle" value=""
									title="<?php echo Text::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)"/>
							</th>
							
							
							
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_JVISUALCSS_ITEMS_DEFAULT', 'a.default', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_JVISUALCSS_ITEMS_STATE', 'a.state', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_JVISUALCSS_ITEMS_TITLE', 'a.title', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_JVISUALCSS_ITEMS_CREATED_BY', 'a.created_by', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_JVISUALCSS_ITEMS_MODIFIED_BY', 'a.modified_by', $listDirn, $listOrder); ?>
							</th>
							
						<th scope="col" class="w-3 d-none d-lg-table-cell" >

							<?php echo HTMLHelper::_('searchtools.sort',  'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>					</th>
						</tr>
						</thead>
						<tfoot>
						<tr>
							<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
								<?php echo $this->pagination->getListFooter(); ?>
							</td>
						</tr>
						</tfoot>
						<tbody <?php if (!empty($saveOrder)) :?> class="js-draggable" data-url="<?php echo $saveOrderingUrl; ?>" data-direction="<?php echo strtolower($listDirn); ?>" <?php endif; ?>>
						<?php foreach ($this->items as $i => $item) :
							$ordering   = ($listOrder == 'a.ordering');
							$canCreate  = $user->authorise('core.create', 'com_jvisualcss');
							$canEdit    = $user->authorise('core.edit', 'com_jvisualcss');
							$canCheckin = $user->authorise('core.manage', 'com_jvisualcss');
							$canChange  = $user->authorise('core.edit.state', 'com_jvisualcss');
							?>
							<tr class="row<?php echo $i % 2; ?>" data-draggable-group='1' data-transition>
								<td class="text-center">
									<?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
								</td>
								<td>
									<?php if ($canChange) : ?>
										<?php echo HTMLHelper::_('jgrid.isdefault', $item->default, $i, 'items.', ($canChange && !$item->default)); ?>
									<?php else : ?>
										<?php echo HTMLHelper::_('jgrid.isdefault', $item->default, $i, 'items.', false); ?>
									<?php endif; ?>
								</td>
								<td>
									<?php echo HTMLHelper::_('jgrid.published', $item->state, $i, 'items.', $canChange); ?>
								</td>
								<td>
									<?php if (isset($item->checked_out) && $item->checked_out && ($canEdit || $canChange)) : ?>
										<?php echo HTMLHelper::_('jgrid.checkedout', $i, $item->uEditor, $item->checked_out_time, 'items.', $canCheckin); ?>
									<?php endif; ?>
									<?php if ($canEdit) : ?>
										<a href="<?php echo Route::_('index.php?option=com_jvisualcss&task=item.edit&id='.(int) $item->id); ?>">
										<?php echo $this->escape($item->title); ?>
										</a>
									<?php else : ?>
													<?php echo $this->escape($item->title); ?>
									<?php endif; ?>
								</td>
								<td>
									<?php echo $item->created_by; ?>
								</td>
								<td>
									<?php echo $item->modified_by; ?>
								</td>
								
								<td class="d-none d-lg-table-cell">
									<?php echo $item->id; ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>

				<input type="hidden" name="task" value=""/>
				<input type="hidden" name="boxchecked" value="0"/>
				<input type="hidden" name="list[fullorder]" value="<?php echo $listOrder; ?> <?php echo $listDirn; ?>"/>
				<?php echo HTMLHelper::_('form.token'); ?>
			</div>
		</div>
	</div>
</form>