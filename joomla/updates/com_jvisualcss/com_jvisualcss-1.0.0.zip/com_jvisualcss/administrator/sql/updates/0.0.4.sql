ALTER TABLE `#__jvisualcss_items` ADD COLUMN `state` TINYINT(4) NOT NULL DEFAULT 1;
UPDATE `#__jvisualcss_items` SET `state` = 1;