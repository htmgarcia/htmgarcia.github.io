<?php
/**
 * @package     Joomla.Package
 * @subpackage  jVisual CSS
 * @copyright   (C) 2025 htmgarcia.com
 * @license     GNU General Public License version 2 or later
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

class pkg_jvisualcssInstallerScript {
    function postflight($type, $parent) {
        if ($type == 'install' || $type == 'update') {
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                        ->delete('#__extensions')
                        ->where('element = ' . $db->quote('pkg_jvisualcss'));
            $db->setQuery($query);
            $db->execute();
        }
    }
}
