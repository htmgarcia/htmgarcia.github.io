<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.jvisualcss
 * @copyright   (C) 2024 htmgarcia.com
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die('Restricted access');

/**
 * @since 0.0.1
 */
class PlgSystemJVisualCss extends CMSPlugin
{
    /**
     * Event method onBeforeCompileHead
     *
     * @since 0.0.1
     * 
     * @return void
     */
    public function onBeforeCompileHead()
    {
        $app = Factory::getApplication();
        $document = Factory::getDocument();
        $user = Factory::getUser();

        // Run only on frontend
        if (!$app->isClient('site'))
        {
            return;
        }

        $this->loadCss();
    }

    /**
     * Load custom CSS in <head>
     * 
     * @since 0.0.1
     * 
     * @return void
     */
    public function loadCss() {
        $db = \Joomla\CMS\Factory::getContainer()->get('DatabaseDriver');

        // Check if table exists
        $tables = $db->getTableList();
        $prefix = $db->getPrefix();
        $tableName = '#__jvisualcss_items';
        $tableWithoutPrefix = str_replace('#__', '', $tableName);
        $fullTableName = str_replace('#__', $prefix, $tableName);

        // Stop if table doesn't exist
        if (!in_array($fullTableName, $tables)) {
            return;
        }

        // Prepare the query
        $query = $db->getQuery(true)
            ->select($db->quoteName(['css']))
            ->from($db->quoteName($tableName))
            ->where($db->quoteName('default') . ' = 1')
            ->where($db->quoteName('state') . ' = 1');

        // Execute the query
        $db->setQuery($query);
        $result = $db->loadAssoc();

        if ($result && $result['css']) {
            $this->objToStyleTag($result['css']);
        }
    }

    /**
     * Convert db data to valid CSS
     * 
     * @since 0.0.1
     * 
     * @param object $jsonData
     * 
     * @return html formated <style> tags, one for each selector
     */
    public function objToStyleTag($jsonData) {
        $cssArray = json_decode($jsonData, true);

        /*echo '<pre>';
        print_r($cssArray);
        echo '</pre>';*/

        // Generate CSS styles
        $cssOutput = "";

        foreach ($cssArray as $cssItem) {
            $selector = $cssItem['selector'];
            $cssId = $this->selectorToId($selector); // Convert selector to valid ID

            $cssOutput .= "<style id=\"{$cssId}\" class=\"jvisualcss-style-tag\">\n";

            // Generate CSS properties
            $cssProperties = [];
            foreach ($cssItem['properties'] as $prop => $value) {
                $formattedValue = '';

                // t+metric r+metric b+metric l+metric. e.g. '10px 10px 10px 10px' (it supports 'auto' too)
                if ( isset($value['t']) 
                    && isset($value['r']) 
                    && isset($value['b']) 
                    && isset($value['l']) 
                    && isset($value['metric'])
                ) {
                    $formattedValue = $this->adjustFlexibleValue($value['t'], $value['metric']) . ' ' .
                        $this->adjustFlexibleValue($value['r'], $value['metric']) . ' ' .
                        $this->adjustFlexibleValue($value['b'], $value['metric']) . ' ' .
                        $this->adjustFlexibleValue($value['l'], $value['metric']);
                } elseif ( isset( $value['base'] )
                    && isset( $value['metric'] )
                ) {
                    if ($this->isSpecialValue($value['metric'])) {
                        // Only include metric and skip base. e.g. 'auto'
                        $formattedValue = (string) $value['metric'];
                    } else {
                        // base + metric. e.g. '10px'
                        $formattedValue = $this->adjustFlexibleValue($value['base'], $value['metric']);
                    }
                } elseif ( isset( $value['base'] ) ) {
                    // value. e.g. '10'
                    $formattedValue = $value['base'];
                } else {
                    // Nothing to do here
                }

                // Remove empty spaces
                $formattedValue = trim($formattedValue);

                $cssProperties[] = ! empty($formattedValue) ? "{$prop}: {$formattedValue};" : '';
            }

            // Combine into CSS block
            $cssOutput .= "{$selector} { " . implode(' ', $cssProperties) . " }\n";

            $cssOutput .= "</style>\n";
        }

        // Insert into <head>
        if (!empty($cssOutput)) {
            // Load CSS into Joomla's head
            $doc = Factory::getApplication()->getDocument();
            $doc->addCustomTag($cssOutput);
        }
    }

    /**
     * Convert selector to valid ID attribute's value
     * 
     * @since 0.0.1
     * 
     * @param string $selector Valid CSS selector
     * 
     * @return string 
     */
    public function selectorToId($selector) {
        return str_replace(
            [' > ', '.', ' ', '[', ']', '#'],  // Match these characters
            ['__gt__', '__dot__', '__sp__', '__lb__', '__rb__', '__hash__'], // Replace with these
            $selector
        );
    }

    public function setDefault()
    {
        // Check for request forgeries
        $this->checkToken();

        $id = $this->input->get('id', 0, 'int');
        $db = Factory::getContainer()->get('DatabaseDriver');

        try {
            // Reset all items to 0
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__jvisualcss_items'))
                ->set($db->quoteName('default') . ' = ' . $db->quote(0));
            $db->setQuery($query);
            $db->execute();

            // Set the selected item to 1
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__jvisualcss_items'))
                ->set($db->quoteName('default') . ' = ' . $db->quote(1))
                ->where($db->quoteName('id') . ' = ' . (int) $id);
            $db->setQuery($query);
            $db->execute();

            if ($db->getAffectedRows() > 0) {
                $this->setMessage(Text::_('COM_JVISUALCSS_ITEM_SET_DEFAULT'));
            }

        } catch (\Exception $e) {
            $this->setMessage($e->getMessage(), 'error');
        }

        $this->setRedirect(Route::_('index.php?option=com_jvisualcss&view=items', false));
    }

    public function isSpecialValue($value) {
        return in_array($value, ['auto']);
    }

    /**
     * Adjust flexible value
     * 
     * @since 0.0.1
     * 
     * @param string $value The value to adjust. e.g. '10' or 'auto'
     * @param string $metric The metric to append to the values. e.g. 'px'
     * 
     * @return string The formatted string without empty spaces
     */
    public function adjustFlexibleValue ( $value, $metric ) {
        return $value && $value !== 'auto' ? intval($value) . $metric : $value;
    }
}
