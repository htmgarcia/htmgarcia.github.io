<?php
/**
 * @autor       Valentin Garcia
 * @website     htmgarcia.com
 * @package     Joomla.Site
 * @subpackage  mod_multi_layouts
 * @copyright   Copyright (C) 2022 Valentin Garcia. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;

if ( !empty($item->imageIntroSrc) ){
	$vg_img_ = $item->imageIntroSrc;
} else {
	$vg_img_ = Uri::base() . 'media/mod_multi_layouts/images/placeholder-300x300.jpg';
}

$cat_title_slug = str_replace(' ', '-', strtolower($item->category_title));
$item_link = Route::_(
	RouteHelper::getCategoryRoute($item->catid, $item->category_language)
);
?>

<div class="multilayouts-grid--item category-<?php 
	echo $cat_title_slug ?>" data-category="category-<?php echo 
	$cat_title_slug ?>">
	<div class="multilayouts-grid--item-inner">
		<h3>
			<a href="<?php 
				echo $item_link ?>"><?php 
					echo $item->title ?>
			</a>
		</h3>
		<img src="<?php 
			echo $vg_img_ ?>" alt="<?php 
			echo htmlspecialchars($item->title) ?>" />
		<?php if (isset($item->link) && $item->readmore != 0) : ?>
			<div class="multilayouts-bottom">
				<?php
				echo LayoutHelper::render(
					'joomla.content.readmore', 
					array('item' => $item, 'params' => $item->params, 'link' => $item->link)
				);
				?>
			</div>
		<?php endif; ?>
	</div>
</div>