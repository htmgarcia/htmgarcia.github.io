<?php
/**
 * @version    CVS: 0.0.1
 * @package    Com_Jvisualcss
 * @author     htmgarcia <htmgarcia@gmail.com>
 * @copyright  2025 htmgarcia
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Jvisualcss\Component\Jvisualcss\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

/**
 * Item controller class.
 *
 * @since  0.0.1
 */
class ItemController extends FormController
{
	protected $view_list = 'items';
}
